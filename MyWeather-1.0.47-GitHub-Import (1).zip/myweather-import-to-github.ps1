# MyWeather 1.0.47: import the original source into the existing draft PR branch.
# Needs Git for Windows and an authenticated GitHub session. No PAT/keystore is needed here.
$ErrorActionPreference = 'Stop'
$branch = 'import/myweather-1.0.47'
$remote = 'https://github.com/alrasby/myweather.git'
$archiveRoot = $PSScriptRoot
$checkout = Join-Path $archiveRoot 'github-checkout'

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    throw 'Git for Windows is required.'
}
if (-not (Test-Path (Join-Path $archiveRoot 'project/package.json'))) {
    throw 'The source project/ directory is missing. Unzip the entire archive first.'
}
$previewFile = Join-Path $archiveRoot 'project/src/lib/auth/preview.ts'
$previewText = Get-Content -LiteralPath $previewFile -Raw
if ($previewText -match '(?s)PREVIEW_CLIENT_SECRET\s*=\s*"[0-9a-f]{64}"') {
    throw 'A hard-coded preview credential was detected. Use only the sanitized import archive.'
}
if (Test-Path $checkout) {
    throw 'github-checkout already exists. Move/remove it manually to avoid overwriting your work.'
}

& git clone --single-branch --branch $branch $remote $checkout
if ($LASTEXITCODE -ne 0) { throw 'Git clone failed. Authenticate Git to GitHub first.' }

# Import the exact archive structure; source remains inside project/.
Get-ChildItem -LiteralPath $archiveRoot -Force | Where-Object {
    $_.Name -notin @('github-checkout', 'myweather-import-to-github.ps1', 'IMPORT_GUIDE_AR.txt')
} | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination $checkout -Recurse -Force
}

Push-Location $checkout
try {
    if (Get-Command node -ErrorAction SilentlyContinue) {
        & node scripts/verify-import.mjs
        if ($LASTEXITCODE -ne 0) { throw 'Source identity preflight failed.' }
    } else {
        Write-Warning 'Node.js is unavailable. CI will verify source identity after push.'
    }

    & git add --all
    if ($LASTEXITCODE -ne 0) { throw 'git add failed.' }
    $changes = & git diff --cached --name-only
    if ($LASTEXITCODE -ne 0) { throw 'git diff failed.' }
    if (-not $changes) { throw 'No new files were staged; nothing has been uploaded.' }
    Write-Host ('Staged files: ' + @($changes).Count)
    & git commit -m 'import: restore MyWeather 1.0.47 original source and regression tests'
    if ($LASTEXITCODE -ne 0) { throw 'git commit failed. Check Git user.name/user.email.' }
    & git push origin $branch
    if ($LASTEXITCODE -ne 0) { throw 'git push failed. Review GitHub permissions and authentication.' }
    Write-Host 'Imported to https://github.com/alrasby/myweather/pull/1'
} finally {
    Pop-Location
}
